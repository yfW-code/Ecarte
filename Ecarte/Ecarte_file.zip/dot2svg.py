import subprocess
import os

if __name__ == '__main__':
    # 指定文件夹路径
    # 构建子图对应节点以及名字列表
    data = "theia"  # cadets theia
    type = "normal"  # abnormal  normal
    # folder_path = 'subgraph/' + data + '/' + type + '_process/'+'abnormal'  # 替换为实际文件夹的路径
    folder_path = 'subgraph/' + data + '/' + type + '_process/' + 'normal'  # 替换为实际文件夹的路径

    # 初始化一个空列表用于存储文件名
    file_names = []

    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        # 使用os.path.join()构建完整的文件路径
        file_path = os.path.join(folder_path, filename)

        # 检查文件是否是普通文件而不是目录
        if os.path.isfile(file_path):
            # 将文件名添加到列表中
            file_names.append(filename)

    # 打印文件名列表
    print("文件名列表:")
    for name in file_names:
        # print(name)
        if '.svg' in name:
            continue
        # 定义要运行的命令
        command = "dot -Tsvg " + folder_path + '/' + name + ' -o ' + folder_path + '/' + name + '.svg' # 例如，这里运行一个列出文件的命令
        # print(command)
        # 使用subprocess运行命令
        try:
            output = subprocess.check_output(command, shell=True, universal_newlines=True)
            # print("命令执行结果:")
            # print(output)
        except subprocess.CalledProcessError as e:
            print(f"命令执行失败，错误码: {e.returncode}")
            print(f"错误消息: {e.output}")
    print("------------------------finish-----------------------------------")