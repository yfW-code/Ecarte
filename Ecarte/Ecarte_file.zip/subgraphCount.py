import os
import re
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
# 读取节点文件，格式为 节点name \t 子图id
def read_file(file_path,nodes):
    node = {}
    with open(file_path, 'r', encoding="utf-8", errors="ignore") as file:
        for line in file:
            parts = line.strip().split('\t')
            if len(parts) == 2:
                id, name = parts
                if id not in node:
                    node[id] = []
                node[id].append(nodes[name])
    return node

def count_node(node_value, consider_ip_port_same, consider_node_name_same):
    results = {}
    if not consider_node_name_same: #相同节点名字视为不同节点
        if not consider_ip_port_same: #相同ip端口不同视为不同节点
            print('节点名字相同视为不同且相同ip端口不同视为不同的情况下')
            for key, value in node_value.items():
                results[key] = len(value)
                print('\t子图' + key + '有' + str(len(value)) + '个节点')

        if consider_ip_port_same: #相同ip端口不同视为相同节点
            print('节点名字相同视为不同且相同ip端口不同视为相同的情况下')
            for key, value in node_value.items():
                total = len(value)
                ip_dic = {}
                # 定义一个正则表达式模式来匹配IPv4地址
                ipv4 = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}$'
                for k in value:
                    if re.match(ipv4, k):
                        parts = ipv4.strip().split(':')
                        ip, port = parts
                        if ip not in ip_dic:
                            ip_dic[ip] = []
                        ip_dic[ip].append(port)
                count = 0
                for k, v in ip_dic.items():
                    count = count + len(v) - len(set(v))
                results[key] = total - count
                print('\t子图' + key + '有' + str(total-count) + '个节点')

    if consider_node_name_same: #相同节点名字视为相同
        if not consider_ip_port_same: #相同ip端口不同视为不同节点
            print('节点名字相同视为相同且相同ip端口不同视为不同的情况下')
            for key, value in node_value.items():
                total = len(set(value))
                results[key] = total
                print('\t子图' + key + '有' + str(total) + '个节点')

        if consider_ip_port_same: #相同ip端口不同视为相同
            print('节点名字相同视为相同且相同ip端口不同视为相同的情况下')
            for key, value in node_value.items():
                temp = set(value)
                total = len(temp)
                t = []
                # 定义一个正则表达式模式来匹配IPv4地址
                ipv4 = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}$'
                for k in temp:
                    if re.match(ipv4, k):
                        parts = ipv4.strip().split(':')
                        ip, port = parts
                        t.append(ip)
                m = total - len(set(t))
                results[key] = m
                # print('\t子图' + key + '有' + str(m) + '个节点')
    return results


def saveSubgraphCountFile(file_name):
    with open(file_name, "w", encoding='utf-8') as f:
        total1 = len(results)
        total2 = total1
        f.write('文件' + node_file + '下:\n')
        f.write('总子图数量为：' + str(total1) + '\n')
        temp = {}
        for key, value in results.items():
            if value not in temp:
                temp[value] = 0
            temp[value] = temp[value] + 1
            if value <= 1:
                total1 = total1 - 1
            if value <= 2:
                total2 = total2 - 1
        f.write('去掉子图节点数量小于等于1的子图数量为' + str(total1) + '\n')
        f.write('去掉子图节点数量小于等于2的子图数量为' + str(total2) + '\n')
        for key, value in temp.items():
            f.write('子图节点数为' + str(key) + '有' + str(value) + '个' + '\n')
    f.close()
def read_node(file_name):
    node = {}
    with open(file_name, 'r') as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            node_uuid = parts[0]
            node_type = parts[1]
            node_name = parts[2]
            # # if re.match(ipv4, node_name):
            # if ':' in node_name:
            #     node_name = node_name.replace(":", "_")
            if node_uuid not in node.keys():
                node[node_uuid] = node_name
    return node

if __name__ == "__main__":
    # graph_file = "te.txt"  # 替换成实际的节点划分文件路径
    dir="H:/data/darpaE3_proprocess_all" # graphWithAttribute_root graphWithRandom_root
    type="cadetsAllFile"   # cadets # theia
    file_type ="cadetsabnormal_process"
    filedir=dir+"/"+type+"/" + file_type
    filelist=os.listdir(filedir)
    node_file = 'H:/data/darpaE3_proprocess_all/cadets_prefixesconverttotalnode.txt'
    nodes = read_node(node_file)  # 节点字典，key为节点uuid,  node_name
    for file in filelist:
        if "infomapUUID" in file:
            node_file =filedir+"/"+ file  # 替换成实际的边文件路径
            print(node_file)
            node_value = read_file(node_file,nodes)

            consider_ip_port_same = True  # True False 情况1和情况2：是否将相同IP不同端口视为同一节点
            consider_node_name_same =True  #  情况3和情况4：是否将相同节点名字视为同一节点
            results = count_node(node_value, consider_ip_port_same, consider_node_name_same)
            filtered_node_counts=defaultdict(int)
            for count in results.values():
                if count >= 2:  # 过滤掉节点数量少于2的子图
                    filtered_node_counts[count] += 1

            x_values = list(filtered_node_counts.keys())
            y_values = list(filtered_node_counts.values())

            min_marker_size = 10  # 最小气泡大小
            max_marker_size = 50  # 最大气泡大小

            # 将子图数量映射到气泡大小范围内
            scaled_subgraph_sizes = np.interp(y_values, (min(y_values), max(y_values)),(min_marker_size, max_marker_size))

            # === 统一字体设置 ===
            plt.rcParams['font.family'] = 'Times New Roman'
            plt.rcParams['axes.unicode_minus'] = False  # 避免负号乱码
            plt.rcParams['font.size'] = 12
            # 创建一个图形
            fig,ax=plt.subplots(figsize=(10, 6))

            # 使用对数刻度绘制横坐标，并设置气泡大小
            for i in range(len(y_values)):
                plt.semilogx(x_values[i], y_values[i], 'o', alpha=0.5, markersize=scaled_subgraph_sizes[i])


            ax.set_xlabel('Number of nodes in a subgraph/Logarithmic scale',fontsize=12, fontname='Times New Roman')
            ax.set_ylabel('Number of subgraphs', fontsize=12, fontname='Times New Roman')


            # 坐标刻度样式（刻度朝内）
            # plt.tick_params(direction='in', length=5, width=1, labelsize=12)
            # === 刻度线朝内（主+次刻度） ===
            ax.tick_params(axis='both', which='major', direction='in', length=6, width=1)
            ax.tick_params(axis='both', which='minor', direction='in', length=3, width=0.8)

            # 网格与边框
            # plt.grid(True, linestyle='--', alpha=0.4)
            # # for spine in ['top', 'right']:
            # #     plt.gca().spines[spine].set_visible(True)

            # 调整布局
            plt.tight_layout()

            # 保存图像（PDF 或 PNG）
            plt.savefig("xxx.pdf", bbox_inches='tight')
            plt.show()

            # # 清空结果
            # results = {}
            #
            #
            # plt.rcParams['font.sans-serif'] = ['TimesNewRoman', 'SimHei']
            # plt.savefig("45")
            results.clear()

















