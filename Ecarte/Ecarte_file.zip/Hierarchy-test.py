
# -*- coding: gbk -*-
import math
import time

from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from sklearn.metrics import silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import csv
from sklearn.metrics import davies_bouldin_score
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import calinski_harabasz_score
from sklearn.metrics import pairwise_distances
import heapq


def judgeVector(clustevector, normalrule,number):
    res = []
    cos = []
    similarity = 0
    cos_similarity = 0
    for line in normalrule:
        dis = eujDistance(clustevector, line)
        cos1 = cosSim(clustevector, line)
        if dis == 0:
            label = True
            return 0, 1
        else:
            res.append(dis)
        if cos1 == 1:
            label = True
            return 0, 1
        else:
            cos.append(cos1)
    # ��С��������,��������
    res.sort(reverse=False)
    cos.sort(reverse=True)
    # print(len(res))




    for i in range(number):
        similarity = similarity+res[i]
        cos_similarity = cos_similarity+cos[i]
    similarity=1.0*similarity/number
    cos_similarity=1.0*cos_similarity/number
    # if similarity > 0.95:
    # 	label = False
    # else:
    # 	label = True
    return similarity, cos_similarity


def eujDistance(vec1, vec2):
    dist = np.linalg.norm(vec1 - vec2, ord=2)
    return dist


def cosSim(a, b):
    a_norm = np.linalg.norm(a)
    b_norm = np.linalg.norm(b)
    cos = np.dot(a, b) / (a_norm * b_norm)
    return cos


def load_sketches(file, dimension):
    """Load sketches in a file from the handle @fh to memory as numpy arrays. """
    sketches = list()
    graphid = list()
    with open(file, 'r', encoding='utf-8') as fh:
        csv_reader = csv.reader(fh)
        next(csv_reader, None)
        sorted_data = sorted(csv_reader, key=lambda row: int(row[0]), reverse=False)
        for line in sorted_data:
            if not len(line) == (dimension + 1):
                continue
            first_column = int(line[0]) + 1
            rest_of_columns = line[1:]
            sketch = list(rest_of_columns)
            sketches.append(sketch)
            graphid.append(first_column)
    # print(np.array(sketches))
    return np.array(sketches).astype(float), graphid


def norm(normal_data):
    l2_norms = np.linalg.norm(normal_data, axis=1)
    normalized_sketches = normal_data / l2_norms[:, np.newaxis]

    # print("ԭʼ����:\n", normal_data)
    # print("L2����:\n", l2_norms)
    # print("��һ���������:\n", normalized_sketches)
    return normalized_sketches



if __name__ == "__main__":
    th = 0.1
    # theia cadets
    data = "fivedirections"
    dimension =128
    # 64 128 256
    prefix = "../data/feature/"
    normalFile = prefix + data + "_normal_" + str(dimension) + ".csv"
    abnormalFile = prefix + data + "_abnormal_" + str(dimension) + ".csv"
    normal_data, normal_ID = load_sketches(normalFile, dimension)
    # test_data, test_ID = load_sketches(abnormalFile, dimension)

    # �ж����Ž� �����
    # ʹ�� fcluster ������ȡÿ�����ݵ������Ĵص�ID
    # Calinski-Harabasz Խ��Խ�ã� Davies-Bouldin IndexԽСԽ��
    silhouette_scores = []
    chi_scores = []
    dbi_scores = []
    # complete average ward single
    Z = linkage(normal_data, method='average')
    for i in range(2,500):
        if i%50==0:
            print(i)
        cluster_ids = fcluster(Z, t=i, criterion='maxclust')  # 5�Ǿ�������������Ը�����Ҫ����
        # if cluster_ids[1]==cluster_ids[18]:
        silhouette_avg = silhouette_score(normal_data, cluster_ids)
        dbi = davies_bouldin_score(normal_data, cluster_ids)  # ���� DBI
        chi = calinski_harabasz_score(normal_data, cluster_ids)  # ���� CHI
        silhouette_scores.append(silhouette_avg)
        chi_scores.append(chi)
        dbi_scores.append(dbi)

    best_n_clusters = silhouette_scores.index(max(silhouette_scores))
    print("------------silhouette_score------------------")
    print(best_n_clusters)
    print(silhouette_scores[silhouette_scores.index(max(silhouette_scores))])


    best_n_clusters = chi_scores.index(max(chi_scores))
    print("------------Calinski-Harabasz------------------")
    print(best_n_clusters)
    print(chi_scores[chi_scores.index(max(chi_scores))])

    best_n_clusters = dbi_scores.index(min(dbi_scores))
    print("------------dbi------------------")
    print(best_n_clusters)
    print(dbi_scores[dbi_scores.index(max(dbi_scores))])
    print("------------------finish-----------------------------------")


    # print(len(normal_data))
    # # normal_data = pairwise_distances(normal_data, metric='euclidean')
    # # complete average ward single
    # Z = linkage(normal_data, method='average')
    # cluster_labels = fcluster(Z, t=(33+2), criterion='maxclust')
    # print(len(cluster_labels))

    # # # ���ÿ�����ݵ������Ĵص�ID
    # # for i, cluster_id in enumerate(cluster_labels):
    # #     print(f"Data Point {normal_ID[i]} belongs to Cluster {cluster_id}")
    # #
    # data = pd.DataFrame(normal_data, columns=[f'Feature {i}' for i in range(1, int(dimension+1))])
    # data_with_clusters = pd.concat([data, pd.Series(cluster_labels, name='Cluster')], axis=1)
    # # # ���¼���ÿ�����������
    # cluster_centers = data_with_clusters.groupby('Cluster').mean()
    #
    # # ������ֵ���Ƴ�ÿ����������������ľ��������ֵ�ĵ�
    # threshold_distance = 0.4
    # cleaned_data = pd.DataFrame()
    # for _, group in data_with_clusters.groupby('Cluster'):
    #     cluster_mean = group[data.columns].mean()
    #     mask = []
    #     for _, row in group.iterrows():
    #         distance = np.linalg.norm(row[data.columns] - cluster_mean)
    #         if distance <= threshold_distance:
    #             mask.append(True)
    #         else:
    #             mask.append(False)
    #     cleaned_data = pd.concat([cleaned_data, group[mask]])



    #
    # # ��������
    # cleaned_data.reset_index(drop=True, inplace=True)
    # print(len(cleaned_data))
    # # ���¼�������
    # cluster_centers = cleaned_data.groupby('Cluster').mean()
    #
    #
    # cluster_center=[]
    # for _, center in cluster_centers.iterrows():
    #     cluster_center.append(center)
    #
    #
    # t1 = time.time()
    # print("-------------------------�����-----------------------------------------------------")
    # print(len(test_data))
    # abnormalcount=0
    # for i in range(len(test_data)):
    #     similarity, cos_similarity = judgeVector(test_data[i], cluster_center,number=1)
    #     # and (math.fabs(similarity - cos_similarity) <= 0.13)
    #     if similarity > 1.45 :
    #     # and math.fabs(cos_similarity) < 0.6 :
    #         abnormalcount = abnormalcount + 1
    #         # print("����� subgraph\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
    #     print("����� subgraph\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
    # print(abnormalcount)
    # t2 = time.time()
    # total_time = t2 - t1
    # print("�����������%s��" % total_time)
    # print("------------------finish-----------------------------------")

















































































    # �ж����Ž� �����
    # # ʹ�� fcluster ������ȡÿ�����ݵ������Ĵص�ID
    # # Calinski-Harabasz Խ��Խ�ã� Davies-Bouldin IndexԽСԽ��
    # silhouette_scores = []
    # chi_scores = []
    # dbi_scores = []
    #
    # for i in range(2,500):
    #     cluster_ids = fcluster(Z, t=i, criterion='maxclust')  # 5�Ǿ�������������Ը�����Ҫ����
    #     # if cluster_ids[1]==cluster_ids[18]:
    #     silhouette_avg = silhouette_score(normal_data, cluster_ids)
    #     dbi = davies_bouldin_score(normal_data, cluster_ids)  # ���� DBI
    #     chi = calinski_harabasz_score(normal_data, cluster_ids)  # ���� CHI
    #     silhouette_scores.append(silhouette_avg)
    #     chi_scores.append(chi)
    #     dbi_scores.append(dbi)
    #
    # best_n_clusters = silhouette_scores.index(max(silhouette_scores))
    # print("------------silhouette_score------------------")
    # print(best_n_clusters)
    # print(silhouette_scores[silhouette_scores.index(max(silhouette_scores))])
    #
    #
    # best_n_clusters = chi_scores.index(max(chi_scores))
    # print("------------Calinski-Harabasz------------------")
    # print(best_n_clusters)
    # print(chi_scores[chi_scores.index(max(chi_scores))])
    #
    # best_n_clusters = dbi_scores.index(min(dbi_scores))
    # print("------------dbi------------------")
    # print(best_n_clusters)
    # print(dbi_scores[dbi_scores.index(max(dbi_scores))])