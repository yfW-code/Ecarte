



def getnodedict(nodefile, nodedict):
    with open(nodefile, 'r', encoding='utf-8') as f:
        for line in f:
            if "uuid\rtype\rname" in line:
                continue
            line = line.split("\t")
            uuid = line[0]
            type = line[1]
            name = line[-1].replace("\n", "").replace("\"", "")
            name = name.replace("\\", "/")
            if uuid not in nodedict.keys():
                nodedict[uuid] = {"type": type, "name": name}
            # else:
            #     print("getnodedict\toldname"+str(nodedict[uuid]['name'])+"\tnewname"+name)
    return nodedict


def getTruth(truthfile):
    abnormalnodeuuid = []
    with open(truthfile, 'r', encoding='utf-8') as fopen:
        for line in fopen:
            line = line.strip()
            assert (len(str(line)) > 1)
            if line not in abnormalnodeuuid:
                abnormalnodeuuid.append(line)
    return abnormalnodeuuid

if __name__ == '__main__':
    data = "cadets"  # cadets  theia
    nodefile = "../data/" + data + "totalnode.txt"
    truthfile="../data/ground-truth/"+data+".txt"
    infomapfile="../data/randomWalk/"+data+"abnormal_process/"+data+"_abnormal_infomapUUID.txt"
    nodedict = {}
    nodedict = getnodedict(nodefile, nodedict)
    abnormalnodeuuid=[]
    abnormalnodeuuid=getTruth(truthfile)
    print("abnormalnodeuuidList length\t" + str(len(abnormalnodeuuid)))
    templist=nodedict.keys()
    attackNum=0
    uuidset=set()
    for item in abnormalnodeuuid:
        if item in templist:
            attackNum=attackNum+1
            uuidset.add(item)
            print(str(item)+"\t"+nodedict[item]['name'])
    print("abnormal length\t" + str(attackNum))
    print("uuidset length\t" + str(len(uuidset)))
    count=0
    nameset=set()
    with open(infomapfile,'r',encoding='utf-8') as fopen:
        for line in fopen:
            line=line.strip().replace("\n","")
            line=line.split("\t")
            assert len(line)==2
            subgraphid=line[0]
            uuid=line[1]
            if uuid in abnormalnodeuuid:
                if  "NA:0".__eq__(nodedict[uuid]['name']):
                    count = count + 1
                    continue
                nameset.add(int(subgraphid))
                count = count + 1
                uuidset.discard(uuid)
                print("--666666--:\t"+str(uuid)+"\t"+str(subgraphid)+"\t"+nodedict[uuid]['name']+"\n")
    print(count)
    b=list(nameset)
    print(len(b))
    b=sorted(b)
    print(b)

    for item in uuidset:
        print(item+"\t"+nodedict[item]['name'])
    print("--------------------------finish-----------------------------------------")
