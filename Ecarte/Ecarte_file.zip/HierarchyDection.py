# -*- coding: gbk -*-
import math
import time

from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from sklearn.metrics import silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import csv
from sklearn.metrics import davies_bouldin_score
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import calinski_harabasz_score
from sklearn.metrics import pairwise_distances
import heapq


def judgeVector(clustevector, normalrule,number):
    res = []
    cos = []
    similarity = 0
    cos_similarity = 0
    for line in normalrule:
        dis = eujDistance(clustevector, line)
        cos1 = cosSim(clustevector, line)
        if dis == 0:
            label = True
            return 0, 1
        else:
            res.append(dis)
        if cos1 == 1:
            label = True
            return 0, 1
        else:
            cos.append(cos1)
    # ��С��������,��������
    res.sort(reverse=False)
    cos.sort(reverse=True)
    # print(len(res))




    for i in range(number):
        similarity = similarity+res[i]
        cos_similarity = cos_similarity+cos[i]
    similarity=1.0*similarity/number
    cos_similarity=1.0*cos_similarity/number
    # if similarity > 0.95:
    # 	label = False
    # else:
    # 	label = True
    return similarity, cos_similarity


def eujDistance(vec1, vec2):
    dist = np.linalg.norm(vec1 - vec2, ord=2)
    return dist


def cosSim(a, b):
    a_norm = np.linalg.norm(a)
    b_norm = np.linalg.norm(b)
    cos = np.dot(a, b) / (a_norm * b_norm)
    return cos


def load_sketches(file, dimension):
    """Load sketches in a file from the handle @fh to memory as numpy arrays. """
    sketches = list()
    graphid = list()
    with open(file, 'r', encoding='utf-8') as fh:
        csv_reader = csv.reader(fh)
        next(csv_reader, None)
        sorted_data = sorted(csv_reader, key=lambda row: int(row[0]), reverse=False)
        for line in sorted_data:
            if not len(line) == (dimension + 1):
                continue
            first_column = int(line[0])
            rest_of_columns = line[1:]
            sketch = list(rest_of_columns)
            sketches.append(sketch)
            graphid.append(first_column)
    # print(np.array(sketches))
    return np.array(sketches).astype(float), graphid


def norm(normal_data):
    l2_norms = np.linalg.norm(normal_data, axis=1)
    normalized_sketches = normal_data / l2_norms[:, np.newaxis]

    # print("ԭʼ����:\n", normal_data)
    # print("L2����:\n", l2_norms)
    # print("��һ���������:\n", normalized_sketches)
    return normalized_sketches



if __name__ == "__main__":
    # theia cadets fivedirections
    data = "cadets"
    dimension =128 # 64 128 256
    threshold=0.8  #3.49 2.83
    prefix = "../data/feature/"
    normalFile = prefix + data + "_normal_" + str(dimension) + ".csv"
    abnormalFile = prefix + data + "_abnormal_" + str(dimension) + ".csv"
    normal_data, normal_ID = load_sketches(normalFile, dimension)
    test_data, test_ID = load_sketches(abnormalFile, dimension)
    if "cadets".__eq__(data):
        tpList = []
        fpListFalse=[]
        less3sub=[22,229,1269,393,426]
        tpList=[4, 5, 6, 7, 8, 9, 12, 14, 15, 17, 21,24, 25, 52,104]
        fpListFalse=[18, 23, 26, 27, 28, 33, 34, 36, 40, 46, 49, 50, 51, 53, 54, 57, 58, 59, 62, 63, 64, 66, 68, 69,
                     70, 72, 73, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 89, 90, 91, 92, 94, 96, 97, 99, 101, 102, 105, 106, 107, 110, 111, 113, 114, 115, 117, 118, 119, 120, 121, 124, 125, 127, 128, 132, 133, 134, 135, 139, 140, 142, 143, 144, 146, 147, 148, 149, 151, 152, 153, 154, 155, 157, 158, 159, 160, 161, 162, 163, 166, 167, 168, 169, 170, 171, 172, 173, 174, 177, 178, 180, 181, 185, 188, 189, 190, 194, 195, 197, 198, 199, 203, 207, 210, 214, 215, 235, 238, 242, 243, 265, 273, 279, 280, 316, 317, 324, 327, 334, 357, 367, 370, 371, 379, 395, 409, 424, 432, 433, 434, 447, 448, 455, 457, 465, 470, 471, 473, 474, 480, 484, 488, 489, 492, 493, 495, 498, 500, 501, 503, 505, 508, 511, 512, 514, 515, 516, 518, 523, 529, 533, 539, 542, 546, 547, 551, 552, 556, 557, 559, 563, 564, 565, 567, 568, 569, 571, 572, 573, 574, 575, 577, 578, 579, 580, 581, 583, 584, 586, 587, 588, 589, 590, 591, 595, 596, 597, 598, 601, 604, 606, 607, 608, 609, 610, 612, 613, 615, 616, 618, 619, 621, 622, 624, 625, 626, 629, 631, 632, 633, 635, 636, 637, 640, 641, 642, 643, 645, 646, 648, 652, 654, 657, 658, 659, 660, 664, 665, 666, 668, 670, 673, 674, 677, 681, 682, 685, 686, 688, 689, 691, 692, 694, 698, 699, 700, 701, 702, 703, 705, 707, 710, 711, 712, 713, 714, 715, 716, 717, 718, 720, 722, 723, 724, 727, 730, 731, 732, 733, 734, 735, 739, 741, 742, 743, 745, 746, 747, 748, 750, 751, 752, 753, 754, 755, 756, 758, 761, 762, 763, 765, 766, 768, 769, 770, 772, 773, 774, 776, 777, 779, 780, 781, 782, 783, 784, 786, 788, 789, 790, 793, 794, 798, 799, 800, 801, 802, 803, 805, 808, 809, 811, 812, 813, 814, 815, 816, 817, 819, 822, 823, 826, 828, 829, 830, 831, 832, 834, 835, 836, 837, 838, 842, 843, 844, 845, 846, 847, 849, 851, 852, 853, 854, 855, 857, 858, 859, 860, 864, 865, 866, 867, 868, 869, 870, 872, 877, 878, 879, 881, 882, 883, 884, 885, 888, 890, 891, 893, 894, 895, 897, 898, 899, 900, 901, 902, 903, 904, 907, 908, 910, 912, 913, 914, 915, 916, 917, 919, 920, 921, 922, 925, 928, 930, 931, 932, 933, 936, 937, 940, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 955, 959, 960, 961, 962, 965, 966, 967, 968, 969, 970, 972, 973, 974, 975, 978, 979, 980, 982, 987, 988, 989, 990, 993, 994, 995, 996, 997, 1000, 1001, 1002, 1004, 1007, 1008, 1009, 1011, 1012, 1013, 1015, 1016, 1018, 1019, 1020, 1021, 1022, 1024, 1025, 1026, 1027, 1028, 1029, 1031, 1032, 1033, 1034, 1035, 1039, 1040, 1041, 1042, 1043, 1044, 1046, 1047, 1048, 1049, 1050, 1051, 1053, 1054, 1056, 1058, 1059, 1061, 1063, 1064, 1065, 1066, 1067, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1081, 1082, 1084, 1086, 1088, 1090, 1092, 1093, 1094, 1097, 1098, 1099, 1101, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1111, 1112, 1113, 1114, 1116, 1117, 1119, 1120, 1121, 1122, 1123, 1124, 1126, 1127, 1130, 1132, 1133, 1134, 1135, 1136, 1138, 1139, 1140, 1141, 1143, 1144, 1145, 1146, 1147, 1148, 1150, 1151, 1153, 1155, 1156, 1157, 1159, 1160, 1161, 1162, 1164, 1165, 1166, 1167, 1168, 1169, 1170, 1172, 1173, 1174, 1175, 1177, 1178, 1180, 1182, 1184, 1185, 1186, 1187, 1188, 1191, 1192, 1193, 1195, 1196, 1198, 1200, 1201, 1204, 1206, 1207, 1208, 1209, 1210, 1212, 1213, 1214, 1216, 1217, 1218, 1219, 1220, 1221, 1225, 1226, 1228, 1230, 1231, 1232, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1247, 1251, 1252, 1253, 1254, 1255, 1257, 1258, 1261, 1262, 1265, 1266, 1270, 1271, 1272, 1273, 1274, 1276, 1277, 1279, 1282, 1283, 1286, 1289, 1290, 1292, 1293, 1297, 1298, 1299, 1300, 1301, 1303, 1304, 1305, 1306, 1310, 1312, 1314, 1316, 1318, 1320, 1322, 1323, 1325, 1326, 1327, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1339, 1340, 1341, 1342, 1343, 1345, 1346, 1348, 1349, 1351, 1352, 1353, 1355, 1356, 1358, 1359, 1360, 1362, 1365, 1367, 1368, 1370, 1373, 1374, 1378, 1381, 1383, 1385, 1386, 1388, 1389, 1390, 1391, 1395, 1396, 1397, 1399, 1401, 1402, 1403, 1404, 1406, 1407, 1408, 1411, 1412, 1413, 1414, 1419, 1420, 1424, 1425, 1431, 1433, 1435, 1437, 1443, 1444, 1446, 1447, 1450, 1451, 1452, 1455, 1456, 1457, 1461, 1462, 1463, 1465, 1466, 1468, 1469, 1471, 1473, 1475, 1477, 1478, 1479, 1482, 1484, 1486, 1487, 1488, 1495, 1497, 1500, 1501, 1503, 1504, 1505, 1508, 1511, 1512, 1513, 1514, 1516, 1518, 1520, 1521, 1522, 1524, 1525, 1529, 1531, 1532, 1534, 1535, 1537, 1538, 1540, 1543, 1544, 1547, 1549, 1551, 1561, 1563, 1569, 1570, 1571, 1572, 1573, 1576, 1579, 1580, 1582, 1587, 1590, 1591, 1592, 1593, 1596, 1597, 1600, 1602, 1609, 1610, 1612, 1616, 1619, 1620, 1621, 1625, 1628, 1630, 1633, 1636, 1641, 1644, 1645, 1650, 1654, 1660, 1661, 1663, 1667, 1673, 1674, 1676, 1679, 1688, 1691, 1693, 1694, 1702, 1704, 1707, 1710, 1712, 1716, 1718, 1727, 1739, 1743, 1745, 1747, 1748, 1758, 1763, 1779, 1786, 1787, 1789, 1798, 1806, 1807, 1813, 1826, 1831, 1836, 1841, 1846, 1849, 1852, 1861, 1864, 1889, 1898, 1900, 1904, 1907, 1909, 1915, 1916, 1920, 1931, 1956, 1959, 1961, 1967, 1971, 1974, 1975, 1976, 1978, 1981, 1987, 2008, 2022, 2029, 2046, 2048, 2051, 2061, 2079, 2082, 2108, 2110, 2112, 2113, 2114, 2128, 2130, 2137, 2148, 2172, 2203, 2212, 2219, 2233, 2237, 2241, 2242, 2255, 2261, 2283, 2284, 2285, 2318, 2325, 2368, 2370, 2397, 2404, 2417, 2470, 2482, 2484, 2526, 2531, 2585, 2591, 2607, 2612, 2630, 2644, 2666, 2675, 2682, 2688, 2709, 2718, 2723, 2724, 2769, 2837, 2865, 2871, 2886, 2921, 2922, 2925, 2943, 3036, 3060, 3071, 3120, 3167, 3169, 3209, 3217, 3243, 3293, 3298, 3415, 3421, 3461, 3489, 3729, 3837, 3849, 3883, 4182, 4519, 4822]



    # �ڵ���������3 ��22 868 967
    if "theia".__eq__(data):
        # 1181 /dev/glx_alsa_675 ����һ���ڵ�
        less3sub =[1181, 1635]
        tpList =  [4, 5, 6, 11, 155, 223, 816, 830, 862, 1426, 1441, 1474, 1510]
        # �ⲿ���ǽ����뵥��ip NA:0 Ϊ�쳣�ڵ���ͼ ������Щ��Ӱ����Ĺ�����ͼ
        fpListFalse = [1, 54, 55, 56, 59, 60, 61, 72, 73, 74, 76, 78, 80, 85, 88, 98, 105, 106, 119, 127, 132, 138, 143, 160, 162, 166, 172,
                       246, 397, 448, 484, 485, 1025, 1100, 1145, 1165, 1189, 1193, 1223, 1271,
                       1287, 1299, 1314, 1325, 1345, 1352, 1410, 1419, 1427, 1428, 1432, 1434, 1436, 1460, 1464, 1472, 1489, 1597]
    if "fivedirections".__eq__(data):
        less3sub = [52,132, 134, 135]
        # [1, 7, 14, 22, 27, 52, 132, 134, 135
        tpList = [1, 7, 14, 22, 27]
        # �ⲿ���ǽ����뵥��ip NA:0 Ϊ�쳣�ڵ���ͼ ������Щ��Ӱ����Ĺ�����ͼ
        fpListFalse = [2, 4, 67, 123, 124, 126, 129, 138, 142, 143, 145, 152, 158, 161, 164, 165, 166, 169, 179, 189, 190, 192, 194, 195, 198, 200]

    print(len(normal_data))
    # normal_data = pairwise_distances(normal_data, metric='euclidean')
    # complete average ward single
    Z = linkage(normal_data, method='average')
    cluster_labels = fcluster(Z, t=(16+2), criterion='maxclust')
    print(len(cluster_labels))

    # # ���ÿ�����ݵ������Ĵص�ID
    # for i, cluster_id in enumerate(cluster_labels):
    #     print(f"Data Point {normal_ID[i]} belongs to Cluster {cluster_id}")
    #
    data = pd.DataFrame(normal_data, columns=[f'Feature {i}' for i in range(1, int(dimension+1))])
    data_with_clusters = pd.concat([data, pd.Series(cluster_labels, name='Cluster')], axis=1)
    # # ���¼���ÿ�����������
    cluster_centers = data_with_clusters.groupby('Cluster').mean()

    # ������ֵ���Ƴ�ÿ����������������ľ��������ֵ�ĵ� cadets 0.4  theia 0.05
    threshold_distance = 0.4
    cleaned_data = pd.DataFrame()
    for _, group in data_with_clusters.groupby('Cluster'):
        cluster_mean = group[data.columns].mean()
        mask = []
        for _, row in group.iterrows():
            distance = np.linalg.norm(row[data.columns] - cluster_mean)
            if distance <= threshold_distance:
                mask.append(True)
            else:
                mask.append(False)
        cleaned_data = pd.concat([cleaned_data, group[mask]])

    # ��������
    cleaned_data.reset_index(drop=True, inplace=True)
    print(len(cleaned_data))
    # ���¼�������
    cluster_centers = cleaned_data.groupby('Cluster').mean()


    cluster_center=[]
    for _, center in cluster_centers.iterrows():
        cluster_center.append(center)


    t1 = time.time()
    print("-------------------------�����-----------------------------------------------------")
    print(len(test_data))
    total = len(test_data)
    tp=0
    temptn=0
    count=0
    for i in range(len(test_data)):
        similarity, cos_similarity = judgeVector(test_data[i], cluster_center,number=1)
        # and (math.fabs(similarity - cos_similarity) <= 0.13)
        if similarity > threshold:
            if test_ID[i] in tpList:
                tp=tp+1
                # print("�쳣\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
            if test_ID[i] in fpListFalse:
                temptn=temptn+1
                # print("����� subgraph\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
            # if test_ID[i] not in fpListFalse and test_ID[i] not in tpList and test_ID[i] not in less3sub:
            #     print("����� subgraph\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
            count=count+1
            print("����� subgraph\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
        # print("����� subgraph\t" + str(test_ID[i]) + "\tsimilarity\t" + str(similarity) + "\tcos\t" + str(cos_similarity) + "\t")
    Truetpcount = len(tpList) + len(less3sub)
    fp=count-tp-temptn
    tp = tp + len(less3sub)
    tn=total-Truetpcount-fp
    fn=Truetpcount-tp
    print("tp\t"+str(tp))
    print("fp\t"+str(fp))
    print("tn\t" + str(tn))
    print("fn\t"+str(fn))
    t2 = time.time()
    total_time = t2 - t1
    print("�����������%s��" % total_time)
    print("------------------finish-----------------------------------")

















































































    # �ж����Ž� �����
    # # ʹ�� fcluster ������ȡÿ�����ݵ������Ĵص�ID
    # # Calinski-Harabasz Խ��Խ�ã� Davies-Bouldin IndexԽСԽ��
    # silhouette_scores = []
    # chi_scores = []
    # dbi_scores = []
    #
    # for i in range(2,500):
    #     cluster_ids = fcluster(Z, t=i, criterion='maxclust')  # 5�Ǿ�������������Ը�����Ҫ����
    #     # if cluster_ids[1]==cluster_ids[18]:
    #     silhouette_avg = silhouette_score(normal_data, cluster_ids)
    #     dbi = davies_bouldin_score(normal_data, cluster_ids)  # ���� DBI
    #     chi = calinski_harabasz_score(normal_data, cluster_ids)  # ���� CHI
    #     silhouette_scores.append(silhouette_avg)
    #     chi_scores.append(chi)
    #     dbi_scores.append(dbi)
    #
    # best_n_clusters = silhouette_scores.index(max(silhouette_scores))
    # print("------------silhouette_score------------------")
    # print(best_n_clusters)
    # print(silhouette_scores[silhouette_scores.index(max(silhouette_scores))])
    #
    #
    # best_n_clusters = chi_scores.index(max(chi_scores))
    # print("------------Calinski-Harabasz------------------")
    # print(best_n_clusters)
    # print(chi_scores[chi_scores.index(max(chi_scores))])
    #
    # best_n_clusters = dbi_scores.index(min(dbi_scores))
    # print("------------dbi------------------")
    # print(best_n_clusters)
    # print(dbi_scores[dbi_scores.index(max(dbi_scores))])