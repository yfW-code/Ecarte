import os
import re
import subprocess
import networkx as nx
from networkx.drawing.nx_pydot import write_dot

ipv4 = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}$'

# 构建子图编号、节点UUID、名字对应的列表
def read_subgraph(UUID_file, Name_file):
    node_name = []
    with open(Name_file, 'r', encoding="utf-8", errors="ignore") as file:
        for line in file:
            parts = line.strip().split('\t')
            if len(parts) == 2:
                subgraph_id, name = parts
                # if re.match(ipv4, name):
                # if ':' in name:
                #     name = name.replace(":", "_")
                node_name.append([subgraph_id, name])

    node_id = []
    with open(UUID_file, 'r', encoding="utf-8", errors="ignore") as file:
        for line in file:
            parts = line.strip().split('\t')
            if len(parts) == 2:
                subgraph_id, id = parts
                node_id.append([subgraph_id, id])
    count = 0
    for t in node_id:
        t.append(node_name[count][1])
        count = count + 1
    return node_id


# 从node中读取数据，以uuidid为索引
def read_node(file_name):
    node = {}
    with open(file_name, 'r') as file:
        lines = file.readlines()[1:]  # 从第二行开始读取
        for line in lines:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            node_uuid = parts[0]
            node_type = parts[1]
            node_name = parts[2]
            # if re.match(ipv4, node_name):
            # if ':' in node_name:
            #     node_name = node_name.replace(":", "_")
            if node_uuid not in node:
                node[node_uuid] = []
            node[node_uuid].append((node_type, node_name))
    return node

# 从边文件中读取数据
def read_edge(file_name):
    edges = []
    with open(file_name, 'r') as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            edge_uuid = parts[0]
            edge_type = parts[1]
            node1 = parts[2]
            node2 = parts[3]
            edges.append((edge_uuid, edge_type, node1, node2))
    return edges

# 从txt文件读取大图数据，处理相同节点和边名的情况
def read_large_graph(file_path):
    G = nx.DiGraph()
    with open(file_path, 'r') as file:
        for line in file:
            # 解析每一行，将边添加到大图中
            parts = line.strip().split('\t')  # 格式： "node1 node2 edge_name"
            node1_uuid = parts[2]
            node2_uuid = parts[3]
            edge_name = parts[1]
            if node1_uuid not in nodes.keys():
                continue
            if node2_uuid not in nodes.keys():
                continue
            # node1 = str(nodes[node1_uuid][0][1])
            # node2 = str(nodes[node2_uuid][0][1])
            node1 = node1_uuid
            node2 = node2_uuid
            if G.has_edge(node1, node2):
                # 如果边已经存在，增加权重
                G[node1][node2]['weight'] += 1
            else:
                # 否则，创建新边
                G.add_edge(node1, node2, label=edge_name, weight = 1)
    return G


# 根据节点列表生成小子图
def create_subgraph(graph, node_list):
    subgraph = graph.subgraph(node_list)
    return subgraph


# 将子图转换为DOT格式并保存
def export_subgraph_to_dot(subgraph, dot_file_path):
    write_dot(subgraph, dot_file_path)


if __name__ == '__main__':
    # 构建子图对应节点以及名字列表
    data = "theia"  # cadets theia
    type = "normal"  # abnormal  normal

    infomapUUID_file = 'H:\\data\\darpaE3_proprocess_all\\' + data + 'AllFile\\' + data + type + '_process\\' + data + '_' + type + '_infomapUUID.txt'
    infomapName_file = 'H:\\data\\darpaE3_proprocess_all\\' + data + 'AllFile\\' + data + type + '_process\\' + data + '_' + type + '_infomapName.txt'
    edge_file = 'H:/data/darpaE3_proprocess_all/'+data+'totaledge.txt'
    node_file = 'H:/data/darpaE3_proprocess_all/'+data+'_prefixesconverttotalnode.txt'
    abnorm_node_file = './'+data+'_abnormal_node.txt'
    results_dir = 'subgraph/'+data+'/'+type+'_process'


    subgraph = read_subgraph(infomapUUID_file, infomapName_file)  # 列表，值为子图编号，节点UUID，节点Name
    edges = read_edge(edge_file)  # 边的列表，包含edge_uuid, edge_type, node1_uuid, node2_uuid
    nodes = read_node(node_file)    # 节点字典，key为节点uuid, value为node_type, node_name

    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    abnorm_nodes = []
    with open(abnorm_node_file, 'r', encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            abnorm_node = parts[0] #根据异常节点id寻找子图
            abnorm_nodes.append(abnorm_node)


    subgraph_node = {}
    for k in subgraph:
        if k[0] not in subgraph_node:
            subgraph_node[k[0]] = []
        subgraph_node[k[0]].append([k[1],k[2]])

    # 读取大图数据
    large_graph = read_large_graph(edge_file)
    print('大图已生成')

    for k,v in subgraph_node.items():
        bool = False
        for t in v:
            if t[1] in abnorm_nodes:
                bool = True
                break
        if bool: # 是异常子图，那么画出来]
            # print('正在生成子图'+ k)
            if not os.path.exists(results_dir+'/abnormal'):
                os.makedirs(results_dir+'/abnormal')
            dot_output_file = results_dir + '/abnormal'+'/subgraph' + k + '.dot'
            node_list = []
            node_uuid_list = []
            for m in v:
                node_list.append(nodes[m[0]][0][1])
                node_uuid_list.append(m[0])
            # 创建小子图
            if len(set(node_list)) <= 3:
                # print(f"--------子图{k}-------------------------------------------------------")
                continue
            uuid_subgraph = create_subgraph(large_graph, node_uuid_list)
            id_subgraph = nx.DiGraph()
            for source, target, data in uuid_subgraph.edges(data=True):
                node1_name = nodes[source][0][1]
                node2_name = nodes[target][0][1]
                n1 = node1_name
                n2 = node2_name
                if re.match(ipv4, node1_name):
                    node1_name = node1_name.split(':')[0]
                if re.match(ipv4, node2_name):
                    node2_name = node2_name.split(':')[0]
                if ':' in node1_name:
                    node1_name = node1_name.replace(":", "_")
                if ':' in node2_name:
                    node2_name = node2_name.replace(":", "_")
                b = False
                if id_subgraph.has_edge(node1_name, node2_name):
                    for edge in id_subgraph.get_edge_data(node1_name, node2_name):
                        if id_subgraph.get_edge_data(node1_name, node2_name, edge)["label"] == data["label"]:
                            id_subgraph[node1_name][node2_name]["weight"] = id_subgraph[node1_name][node2_name]["weight"] + data["weight"]
                            b = True
                            break
                if not b:
                    id_subgraph.add_edge(node1_name, node2_name, label=data["label"], weight = data["weight"])

                if n1 in abnorm_nodes:
                    id_subgraph.nodes[node1_name]["color"] = "red"
                if nodes[source][0][0] == 'process':
                    id_subgraph.nodes[node1_name]["shape"] = "box"
                elif nodes[source][0][0] == 'netflow':
                    id_subgraph.nodes[node1_name]["shape"] = "diamond"
                elif nodes[source][0][0] == 'file':
                    id_subgraph.nodes[node1_name]["shape"] = "ellipse"

                if n2 in abnorm_nodes:
                    id_subgraph.nodes[node2_name]["color"] = "red"
                if nodes[target][0][0] == 'process':
                    id_subgraph.nodes[node2_name]["shape"] = "box"
                elif nodes[target][0][0] == 'netflow':
                    id_subgraph.nodes[node2_name]["shape"] = "diamond"
                elif nodes[target][0][0] == 'file':
                    id_subgraph.nodes[node2_name]["shape"] = "ellipse"

            # 遍历图的所有边，并修改标签
            for source, target, data in id_subgraph.edges(data=True):
                # 获取边的标签
                old_label = data.get('label')
                old_weight = data.get('weight')
                new_label = old_label + '\n' + str(old_weight)
                # 设置新标签
                data['label'] = new_label

            export_subgraph_to_dot(id_subgraph, dot_output_file)
            # print('子图'+k+'生成完成')
        else:
            # print('正在生成子图' + k)
            if not os.path.exists(results_dir+'/normal'):
                os.makedirs(results_dir+'/normal')
            dot_output_file = results_dir + '/normal/subgraph' + k + '.dot'
            node_list = []
            node_uuid_list = []
            for m in v:
                node_list.append(nodes[m[0]][0][1])
                node_uuid_list.append(m[0])
            if len(set(node_list)) <= 3:
                # print(f"--------子图{k}-------------------------------------------------------")
                continue
            # 创建小子图
            uuid_subgraph = create_subgraph(large_graph, node_uuid_list)

            id_subgraph = nx.DiGraph()
            for source, target, data in uuid_subgraph.edges(data=True):
                node1_name = nodes[source][0][1]
                node2_name = nodes[target][0][1]
                n1 = node1_name
                n2 = node2_name
                if re.match(ipv4, node1_name):
                    node1_name = node1_name.split(':')[0]
                if re.match(ipv4, node2_name):
                    node2_name = node2_name.split(':')[0]
                if ':' in node1_name:
                    node1_name = node1_name.replace(":", "_")
                if ':' in node2_name:
                    node2_name = node2_name.replace(":", "_")
                b = False
                if id_subgraph.has_edge(node1_name, node2_name):
                    for edge in id_subgraph.get_edge_data(node1_name, node2_name):
                        if id_subgraph.get_edge_data(node1_name, node2_name, edge)["label"] == data["label"]:
                            id_subgraph[node1_name][node2_name]["weight"] = id_subgraph[node1_name][node2_name]["weight"] + data["weight"]
                            b = True
                            break
                if not b:
                    id_subgraph.add_edge(node1_name, node2_name, label=data["label"], weight=data["weight"])

                if n1 in abnorm_nodes:
                    id_subgraph.nodes[node1_name]["color"] = "red"
                if nodes[source][0][0] == 'process':
                    id_subgraph.nodes[node1_name]["shape"] = "box"
                elif nodes[source][0][0] == 'netflow':
                    id_subgraph.nodes[node1_name]["shape"] = "diamond"
                elif nodes[source][0][0] == 'file':
                    id_subgraph.nodes[node1_name]["shape"] = "ellipse"

                if n2 in abnorm_nodes:
                    id_subgraph.nodes[node2_name]["color"] = "red"
                if nodes[target][0][0] == 'process':
                    id_subgraph.nodes[node2_name]["shape"] = "box"
                elif nodes[target][0][0] == 'netflow':
                    id_subgraph.nodes[node2_name]["shape"] = "diamond"
                elif nodes[target][0][0] == 'file':
                    id_subgraph.nodes[node2_name]["shape"] = "ellipse"

            # 遍历图的所有边，并修改标签
            for source, target, data in id_subgraph.edges(data=True):
                # 获取边的标签
                old_label = data.get('label')
                old_weight = data.get('weight')
                new_label = old_label + '\n' + str(old_weight)
                # 设置新标签
                data['label'] = new_label
            export_subgraph_to_dot(id_subgraph, dot_output_file)
            # print('子图' + k + '生成完成')